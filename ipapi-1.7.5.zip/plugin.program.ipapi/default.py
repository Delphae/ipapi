import urllib,urllib2,re,xbmcplugin,xbmcgui,sys,xbmc,xbmcaddon,os
from resources.libs.common_addon import Addon

#import json, socket
import json
from datetime import datetime as dt
import time
from AirPy import Airvpn
import platform

addon_id = 'plugin.program.ipapi'
addon = Addon('plugin.program.ipapi', sys.argv)
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))

#Network
#internalip = xbmc.getInfoLabel('Network.IPAddress')
#gateway = xbmc.getInfoLabel('Network.GatewayAddress')
dns1 = xbmc.getInfoLabel('Network.DNS1Address')
#dns2 = xbmc.getInfoLabel('Network.DNS2Address')
#mac = xbmc.getInfoLabel('Network.MacAddress')



#fname = xbmc.getInfoLabel('System.FriendlyName').replace('XBMC (','').replace(')','')

#System
#systime = xbmc.getInfoLabel('System.Time')
#sysdate = xbmc.getInfoLabel('System.Date')
#sysdate = xbmc.getInfoLabel('System.Date(DDD yyyy-mm-dd)')
#hddused = xbmc.getInfoLabel('System.UsedSpace')
#hddfree  = xbmc.getInfoLabel('System.FreeSpace')
#hddtotal = xbmc.getInfoLabel('System.TotalSpace')
#hddperc  = xbmc.getInfoLabel('System.FreeSpacePercent')
#sysbuild = xbmc.getInfoLabel('System.BuildVersion')
#sysbuilddate = xbmc.getInfoLabel('System.BuildDate')
#freemem = xbmc.getInfoLabel('System.FreeMemory')
#screen = xbmc.getInfoLabel('System.ScreenMode')
#lang = xbmc.getInfoLabel('System.Language')
#plat = sys.platform
#resolution = xbmc.getInfoLabel('System.ScreenResolution')
#uptime = xbmc.getInfoLabel('System.Uptime')
#totaluptime = xbmc.getInfoLabel('System.TotalUptime')


def getgeoinfo():
    data = {'ip':'', 'hostname':'', 'city':'', 'country':'', 'asn':''}

    url = 'http://ip-api.com/json'
    headers = {'User-Agent': 'Mozilla/5.0'}
    request = urllib2.Request(url, headers=headers)
    try:
        response = urllib2.urlopen(request, timeout=5)
        data     = json.load(response)
        data['hostname']=urllib2.urlopen('http://icanhazptr.com').read()
    except:
        pass
    return data

def ipaddress():
    try:
        ipv4=urllib2.urlopen('http://v4.ipv6-test.com/api/myip.php').read()
    except:
        ipv4=''
    try:
        ipv6=urllib2.urlopen('http://v6.ipv6-test.com/api/myip.php').read()
    except:
        ipv6=''
    return {'ipv4':ipv4, 'ipv6':ipv6}


APIKEY = "ebe97ae18e1b0166c8036f62ed5c133e6b6ac034"
def mysession():
    airvpn = Airvpn(APIKEY, "nl")
    now = dt.now()

    if hasattr(airvpn, 'sessions'):
        for session in airvpn.sessions:
            if session.device_name==platform.node():
                timestamp = int(session.connected_since_unix)
                connected = dt.fromtimestamp(timestamp)
                uptime =  now - connected
                hours = uptime.seconds // 3600
                minutes = uptime.seconds % 3600 // 60
                return {'connected':str(connected),
                    'uptime':'%d, %02d:%02d' % (uptime.days, hours, minutes),
                    'server':session.server_name,
                    'device':session.device_name,
                    'country':session.server_country_code.upper()}
    return {'connected':'vpn disabled', 'uptime':'', 'server':'', 'device':'', 'country':''}


def Network():
    geoinfo = getgeoinfo()
    session = mysession()

    addDir('[B][COLOR white]Connected:[/COLOR][/B] ' + session['device'] +', '+ session['connected'], '','',icon,'',fanart)
    addDir('[B][COLOR white]Uptime:[/COLOR][/B] ' + session['uptime'], '','',icon,'',fanart)
    addDir('[B][COLOR white]Server:[/COLOR][/B] ' + session['server'] +', '+ session['country'], '','',icon,'',fanart)
#    addDir('[B][COLOR white]Device:[/COLOR][/B] ' + session['device'], '','',icon,'',fanart)
#    addDir('[B][COLOR white]Country:[/COLOR][/B] ' + session['country'], '','',icon,'',fanart)
    
    addDir('[B][COLOR white]Location:[/COLOR][/B] ' + geoinfo['city'] + ', ' + geoinfo['country'],'','',icon,'',fanart)
    addDir('[B][COLOR white]IPv4 address:[/COLOR][/B] ' + ipaddress()['ipv4'],'','',icon,'',fanart)
    addDir('[B][COLOR white]IPv6 address:[/COLOR][/B] ' + ipaddress()['ipv6'],'','',icon,'',fanart)
    addDir('[B][COLOR white]Organisation:[/COLOR][/B] ' + geoinfo['isp'],'','',icon,'',fanart)
#    addDir('[B][COLOR white]Hostname:[/COLOR][/B] ' + geoinfo['hostname'],'','',icon,'',fanart)
#    addDir('[B][COLOR white]Internal address:[/COLOR][/B] ' + internalip ,'','',icon,'',fanart)
#    addDir('[B][COLOR white]Gateway:[/COLOR][/B] ' + gateway ,'','',icon,'',fanart)
    addDir('[B][COLOR white]DNS:[/COLOR][/B] ' + dns1 ,'','',icon,'',fanart)

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]                         
        return param

          

def addDir(name,url,mode,iconimage,description,fanart):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok 

 

params=get_params(); url=None; name=None; mode=None; site=None
try: site=urllib.unquote_plus(params["site"])
except: pass
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass


print "Site: "+str(site); print "Mode: "+str(mode); print "URL: "+str(url); print "Name: "+str(name)

'''
if mode==None or url==None or len(url)<1: Index()
elif mode==1: Network()
elif mode==2: System()
'''

Network()

xbmcplugin.endOfDirectory(int(sys.argv[1]))

